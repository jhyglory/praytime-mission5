# PrayTime · Final Design & Brand Source of Truth

## A-copy release approved · 2026-11-08

The user approved the verified local A-copy and requests commit/push/deploy. Earlier local-only holds are satisfied for this release. Use the existing feature branch, PR #1 and Vercel project; verify the public3widths without real submissions or DB operations. Keep approved design/motion/assets/backend/env/privacy unchanged. No main/merge/new PR/DNS change. See COPY_A_LOCAL.md for prior exact local checks and PR #1 for final deployment identity/public evidence.

## Current local A-copy task · 2026-11-08

Use the user's A manuscript for all8 copy groups,7FAQ items and specified form labels/helpers/CTA. Preserve all design/assets/typography, animation clocks, fields/options/required/validation/API/consent/Privacy URL, anchor/event/ARIA IDs and reduced motion. Existing static upper-light→lower-navy intro remains unchanged; the manuscript's “white intro” names the existing separate card-free scene and does not authorize recoloring the actual logo/background in this copy-only task. On Mobile preserve the original Hero editorial352px, GAP heading132px/body90px and Time Select body78px copy slots so shorter text cannot move CTAs/light/phone. Longer prayer/FAQ/form text uses natural flow without global font or spacing changes. LOCAL-ONLY: no commit/push/deploy/PR update/merge/production signup or DB operation. See [COPY_A_LOCAL.md](COPY_A_LOCAL.md) for actual verification and exclusions. Older release/copy instructions are historical for this task.

## Latest intro clarification · 2026-11-08

The latest user correction restores the original STATIC upper-light→lower-navy intro gradient. The upper 그래서 area stays Soft Paper even after the word disappears, the actual logo appears and playback completes. Paper opacity stays1; no temporal background/handoff fade. Restore the original blurred paper geometry and keep4600ms/600ms word/light/logo timing, reduced/no-JS readability and the separate SNS scene. Other sections, including bright WHY NOW, are unchanged. See [INTRO_BACKGROUND_HANDOFF.md](INTRO_BACKGROUND_HANDOFF.md); the1fceb61 full-scene timed fade is superseded.

## Latest four-interaction patch authority · 2026-11-06

The latest explicit four-item request overrides conflicting rules below: outline paper-plane shares everywhere in SNS; cards at70% of the prior15s speed (15000÷0.7=21428.571428571428ms), alternating Desktop↑↓↑↓↑↓ / Mobile↑↓↑; unchanged12s upward hearts/planes; Prayer highlights at each stage's20% /existing50% /80%; restored white-area black그래서 → thin light/background transition → actual red Pause Mark/wordmark+은 on navy, using the4s entry timeline. No dots, obsolete bridge sentence or SNS decorations in the intro. Preserve80 unique photos, separate SNS copy, reduced-motion/entry/pause behavior and all unrelated product/legal/backend constraints. Current sources and new verification belong in [FOUR_INTERACTIONS_PATCH.md](FOUR_INTERACTIONS_PATCH.md). Earlier all-UP15s/all-navy or centered-light rules and their PASS/release records are historical, not current authority.

## Historical: Whole-page final correction · 2026-11-06

This task covers every Desktop/Mobile landing section. Latest explicit user requirements override final1209:514/1051 Figma, which overrides older repository restrictions. Remove narrow “other sections unchanged” scope,100%/70% transparent/lavender gauges,3000ms/50% trigger/sessionStorage latch, and alternating-column behavior. Stats now1400ms/40% independent visibility, both red34.3%/25.3% of a gray100% track, once per page load and replay on reload. SNS columns all rise; independent intro gets sufficient viewport height. Audit every section at1440/393/360 and publish real24s+/reload/interaction evidence. Product/security/approved original assets and existing live backend remain unchanged. See AGENTS.md and docs/WHOLE_PAGE_FINAL.md. Earlier stage records below are historical where they conflict.


## Historical: Fullscreen alternating SNS override · superseded

Latest user instruction changes ONLY the “손이 먼저 움직인 순간” card scene: fill the viewport (100vh fallback /100dvh), cover-scale the original artwork, center the static declaration, and alternate columns up/down/up/down. Use the same12s linear cycle, authored phase and two identical tiles; downward columns run−cycleHeight→0. Keep the independent clean intro at760/680px, original80-photo mapping, particles, reduced-motion/offscreen pause and all other interactions/backend. This explicit instruction supersedes fixed SNS scene heights and all-up motion in older Figma notes. No dependency, Figma/DB/DNS/main/merge changes. See docs/FULLSCREEN_SNS_PATCH.md.


## Historical: Previous intro/SNS-only specification · superseded

Use full Desktop1209:514 / Mobile1209:1051 for layout and previews1265:8215 /1265:11339 for the clean intro's entrance values. The user explicitly requires two independent sections: animate the WHOLE “그래서” word, then the actual exported Figma wordmark plus “은”, once on intro entry; hold the readable result without scene crossfade or auto-scroll. Entrance milestones are150.4–649.6ms /1350.4–1950.4ms with source easing, within the preview's4s clean window. Do not restore letter-by-letter text or a text/CSS substitute logo. The SNS scene stays separate with fixed copy,12s linear columns,16hearts/4shares and original80 ZIP Photos assigned once per base cycle. The supplied ZIP matches all existing80 photo bytes. Use an equivalent full-cycle translation and duplicate tile rather than interpolate the export's1.2ms internal column teleport. Reduced motion now retains static cards and readable text; no-JS keeps readable copy. Mobile WHY uses32/48 and26/44 even below393px. Center each GAP condition, actual light and CTA/arrow flex group on one panel axis. Preserve all other interactions, live backend/privacy guard, favicon/OG and source photos. No DB operation, Figma mutation, dependency, main/merge or DNS change. Existing authorized feature/PR1/Vercel workflow continues after checks. See docs/FINAL_SNS_PATCH.md. Earlier static-intro notes below are historical.


## Historical: Prototype correction · superseded

The user's latest prototype is Desktop1214:651 on page1209:513, starting at full Landing1209:514. Its companion Mobile preview is1214:830 (full Landing1209:1051). These supersede the previous combined16s board1265:8215 for this intro/card patch. The full Landing has a separate clean text-only intro (Desktop1265:8075, Mobile1265:8099), followed by a separate card-declaration scene. Both clean roots return an empty motion inventory; do not invent an auto-fade between the two scroll sections. Each section is760px Desktop /680px Mobile. Card scenes loop continuously every12000ms while declaration/anchor copy stays visible. Desktop six24-card cycles and Mobile three36-card cycles each duplicate once for seamless stream resets;20 decorative particles per viewport. All80 original photo assets are verified against their Figma image hashes. Use the actual Mobile geometry, not a scaled/cropped Desktop scene. Preserve all other sections and explicit CTA/GAP-label/favicon overrides, shadcn, live backend/privacy guard and success alert. No DB operations, Figma edits, dependency, merge/main or DNS changes. Continue the existing authorized feature/PR1/Vercel workflow after checks. See docs/PROTOTYPE_CORRECTION.md. Historical notes below are superseded where they conflict.


## Historical: Previous intro design

The user supplied full-motion1265:8215 and clean-intro1265:8081. These replace ONLY the WHY NOW→THE GAP transition with a16-second loop: clean “그래서” then PRAYTIME은,4-second card-free intro, followed by six moving SNS card columns,20 decorative heart/share streams and the approved declaration. New source timing supersedes the old6-second/three-letter transition. Use native WAAPI with exact exported tracks, offscreen/background pause, and readable reduced/no-JS fallback. Preserve all other sections, anchors, shadcn, favicon/OG, live backend and success alert. Mobile follow-up1209:1073 is WHY NOW, not an intro: follow that frame's32/48 headline,26/44 support, dark lower threshold, and gray6px proportional red gauges on mobile. Desktop gauges retain the existing reference treatment. Mobile intro is responsive adaptation of the supplied Desktop scene, not a claimed Mobile Figma match. No Figma edits, new dependency, DB operations, merge/main or DNS changes. See docs/CARD_INTRO_PATCH.md.

## 실제 접수 활성화 승인 · 2026-11-06

사용자가 실제 저장을 요청했고, 수집 항목 정정안 게시를 승인했다. 기존 Privacy URL에 정정안을 게시한 뒤 HTTP 200 및 본문을 확인했다. 새 snapshot/version과 `PRIVACY_COLLECTION_APPROVED=true`를 사용한다. Production에서 기존 Supabase 연결과 `BETA_SIGNUP_PERSISTENCE=supabase`를 설정하는 release를 진행한다. Preview·자동 테스트·기본 로컬 설정은 disabled다. 기존 beta_signups/UNIQUE(email)/INSERT 전용 RLS를 유지하며, 새 DB·migration·공개 SELECT/UPDATE/DELETE·service-role key는 없다. 사용자가 승인한 QA 신청 1건만 생성·검증하고 기존 신청자 행은 조회·수정하지 않는다. merge·main 변경·DNS 전환은 계속 금지다. 아래 이전 저장 OFF/법률 문구 작성 금지 기록은 이 승인 이전의 이력이다. 실제 배포/QA 결과는 docs/BACKEND_ACTIVATION.md에 기록한다.

## Latest design authority · 2026-11-06

The user selected the current Figma page933:2. MCP verified the visible Desktop1088:916 / Mobile1088:1251 and reread their updated contents. The continuous Dark Hero/ONE QUESTION, architectural GAP and full choice/prayer/transition light layers now supersede the earlier slit-only/omitted-light instructions in historical notes below. Keep the user-approved6s reading pace, the later Lovable-reference3s/no-gray100%red/70%lavender statistics, existing interactions/shadcn, selected sharing image/favicon and disabled backend/privacy guard. See [LATEST_DESIGN_REFRESH.md](LATEST_DESIGN_REFRESH.md) for exact scope and current checks. The previously authorized existing feature/PR/Vercel workflow continues; no merge/main/DB/DNS change.

## 1. World Kernel

World Kernel is frozen.

Core concepts:

- **Noise / Autopilot**: the automatic digital flow
- **The Gap**: the small space between impulse and action
- **Pause Mark `Ⅱ`**: the threshold / everyday identifier
- **Prayer Space**: the short space where the user pauses and prays
- **Prayer Light**: an environmental response, not a reward
- **Puzz**: Companion of the Pause
- **Intentional Choice**: the desired product result

World statement:

**충동과 행동 사이, 기도가 머물 작은 틈을 만듭니다.**

English concept:

**Between impulse and action, make room for prayer.**

## 2. Final Brand Direction

Primary brand direction:

**Quiet Edit**

Core interpretation:

- “다음 행동 앞의 빈 줄”
- visual spacing as a product principle
- editorial clarity
- deliberate rhythm
- intentional gaps
- restrained composition

Quiet Edit is not a magazine aesthetic for its own sake.

It is the visual translation of creating a deliberate pause before the next action.

## 3. Signature Object

Primary signature object:

**Offset Interval · B Refinement v1.1**

Figma source:

- node `896:14`

Meaning:

**Space before action · 행동 전의 틈**

Usage priority:

### HERO / BRAND MOMENT
Allowed prominently:

- Landing Hero
- launch campaign
- brand film
- onboarding cover
- App Store visuals

### MOMENT
Limited:

- Prayer Space transition
- selected brand transition
- special reflective moment

### PRODUCT UI
Very restrained:

Do not repeat it across ordinary app screens, forms, settings, or cards.

The app must still feel like PrayTime without the signature object.

## 4. Secondary Influences

### Still Field
Borrow only:

- low, pooled Prayer Light
- calm environmental depth
- quiet atmosphere

### Second Look
Borrow only:

- product-message clarity
- the question of whether the app is still needed
- reconsideration language

Do not turn these into additional brand directions.

## 5. Puzz

Role:

**Companion of the Pause**

Approved source:

- `Puzz · Dark Spatial Render v1.0`
- Figma node `834:48`

Puzz should feel:

- warm
- calm
- gentle
- non-judgmental
- slightly playful
- restrained

Puzz must not:

- speak for God
- evaluate faith
- tell the user that God is pleased/displeased
- become the visual hero of every screen
- turn PrayTime into a mascot-first app

Use Puzz sparingly in prayer/guidance/companion contexts.

## 6. Adopted Pause Mark UI Patterns

Source board:

- Figma node `906:3`

Adopted:

### 01 · Threshold
Use in PAUSE / entry moment.

Pause Mark is centered and represents entry into Prayer Space.

### 03 · Clear Choice
Use in CHOOSE.

Pause identity appears above the question while the two choices remain visually equal.

Not adopted:

### 02 · Quiet Reading
Do not force a strong glowing Pause Mark next to prayer reading content.

Prayer reading should rely on typography and quiet atmosphere.

## 7. Visual Pillars

### SPACE
Use deliberate negative space and intervals.

### LIGHT
Light indicates focus and atmosphere.

### EDITORIAL CLARITY
Typography and hierarchy explain the product before decoration.

### MATERIAL
Use dimensional material selectively.

### HUMAN COMPANION
Use Puzz only where emotional warmth helps.

## 8. Color Roles

Core roles:

- **Night Canvas**: main dark space
- **Raised Surface**: functional separation
- **Warm White**: main text / clarity
- **Prayer Accent**: calm/focus/atmosphere
- **Signal Red**: decisive action / pause identity

Signal Red should not dominate whole sections.

Prayer Accent should not become a large pastel theme.

## 9. Material Hierarchy

### Level 0
Flat dark canvas.

### Level 1
Raised dark surface.

### Level 2
Controlled reflection / rim / subtle dimensional treatment.

### Level 3
Signature Object material.

Level 3 is for brand moments, not normal app cards.

## 10. Lighting Hierarchy

### BASE
Utility areas, forms, FAQ, settings-like surfaces. Almost flat.

### FOCUS
Prayer, choice, key action. Subtle atmosphere and depth.

### HERO
Landing Hero / brand moment. Signature object and stronger atmospheric treatment allowed.

## 11. Anti-patterns

Avoid:

- generic dark SaaS
- neon cyberpunk
- gaming HUD
- giant gradients everywhere
- excessive glassmorphism
- card stacks
- borders everywhere
- red backgrounds everywhere
- giant Puzz
- church-app clichés
- floating crosses
- stars / planets / galaxies
- literal “space” imagery

The desired sense of space comes from:

**depth + light + interval + typography**

## Final visual authority

Final visual sources are Desktop `1088:916` and Mobile `1088:1251`, using each for its corresponding viewport. THE GAP is Desktop `1088:986` / Mobile child `1088:1319`. These supersede the933/913 Landing frames; Handoff `933:5` is historical reference only. FAQ remains Light Background + seven questions with Ink text and the approved chevron. Do not edit Figma or reopen branding decisions.

Hero remains full bleed with a transparent overlay header. All Light section backgrounds use Soft Paper **#F5F2F7**. THE GAP is Dark, Time Select Light, Voluntary Prayer Dark, FAQ Light and form Light. Preserve exact viewport typography, line-height and section spacing, including the phone silhouette mask around the supplied 10-minute Time Select image. Data numbers are Ink with proportional red gauges. Equal Choice must keep both outcomes at equal visual weight. No purple CTA/type/data or new visual exploration; Puzz and signature object use the provided originals.

The user's explicit final lighting instruction takes precedence over stale exported effects: only the Vertical Slit emits light in THE GAP/transition. Omit floor reflection, surrounding bloom, horizontal glow and the associated broad ambient/aperture layers. This is a requested removal, not a new design direction. Preserve the separate final Prayer section divider treatment and original companion artwork shown in its frame.

The final visual patch builds on the existing section-file extraction, seven-item FAQ and actual shadcn/ui Accordion/Button adoption. Accordion retains the copy/Light/Ink/chevron/ARIA structure; Button retains native button/link semantics and disabled/submitting states. shadcn's generic theme is not the visual authority.

WHY NOW → THE GAP is final; **PENDING DESIGN has ended**. Figma motion context defines Desktop2800ms and Mobile2410ms looping opacity timelines. SignatureTransition uses native Web Animations API for twelve retained tracks, pauses offscreen/in the background, and supplies a reduced-motion/static fallback. Five reflection/ambient/aperture tracks per viewport are omitted under the user's removal instruction. There is no sticky/scroll-progress behavior, scroll hijacking, WebGL or new motion dependency. See MOTION_PLAN.md. The patch remains local pending the user's approval; no commit/push/deployment.

## Release authorization update · 2026-11-06

The user has now approved committing/pushing this final visual + favicon implementation, updating the existing PR #1 and redeploying the existing Vercel project. Earlier pre-approval publishing holds in this stage are satisfied. Keep feature/mission-5-landing, PR #1, main, the privacy guard and disabled persistence. No merge, actual DB INSERT, new DB or custom-domain DNS cutover is authorized.

## Current micro-interaction release scope · 2026-11-06

The final visual/favicon release is complete at `7c77356`. The subsequent micro-interaction patch includes: Hero pointer response, equal GAP anchor interactions (`#hero` / `#how-it-works`, confirmed by the user), active navigation and one-time WHY NOW count-up. Preserve the approved Figma layout/copy, existing transition, shadcn, wheel, form/API and privacy guard. No new dependency. After the diff and passing checks were reported, the user explicitly instructed “재배포해” on 2026-11-06. Commit/push on the existing feature branch, update PR #1 and redeploy the existing Vercel project are now authorized; the earlier local-only hold is satisfied. Merge, main changes, real DB storage and DNS cutover remain forbidden. See [MICRO_INTERACTIONS.md](MICRO_INTERACTIONS.md) for current implementation and fresh checks.

Latest user timing correction: after the deployed-site review, “그래서” was reported too fast. Only the transition reading pace is now overridden:6000ms loop for both viewports, word1050ms full hold, both bridge lines1550ms simultaneous full hold. Original Figma opacity/easing/sequence/layout are preserved. This later feedback supersedes the earlier keep-transition-timing instruction; see MOTION_PLAN.md. Other micro-interactions and release/privacy restrictions remain unchanged.

Earlier user-approved WHY NOW presentation (superseded by the reference correction below): the gray track is removed and each red accent fills to its own displayed maximum34.3 /25.3. Exact visible/accessible percentages and cited source stay unchanged. These decorative count-completion accents do not encode a shared0–100 statistical scale. This explicit approval supersedes the original proportional-gauge styling; other layout/copy/interaction/backend constraints remain intact.

Current WHY NOW reference correction: the user explicitly selected https://praytime.glorifier.kr/ for the gauge and speed. Verified StatMetric source/rendering:3000ms cubic ease-out,7px square bars,no gray,first100% red#FF4438/second70% lavender#C4C0F0,each card triggers at50% with bottom-15% rootMargin. Copy these details only. Mission5 Ink numbers/exact34.3%/25.3%/source/copy/type/layout/accessibility remain, with session-once and reduced/no-JS final fallback. This overrides the earlier750ms/equal-width gauge treatment;6s transition and backend/privacy remain unchanged.
